# Udacity Front-end Nonodegree Project 
## Frogger Arcade Game

##Description
This is a different version of the classic arcade game Frogger.

##Instructions
To play the game download all the files and open index.html in your browser.
Alternatively, you can play the game on github pages (see note below).

##How to play
Use the arrow keys to move the character.
Avoid hitting the bugs while trying to make it to the water on the other side of the road. When you reach the water your character automatically moves back to the grass so that you can try again and you score a point.
